# Pet
A Machine learning project in python to predict if the pet will be adopted or not based on their features.
It uses Logistic Regression to predict if the pet is adopted or not.
